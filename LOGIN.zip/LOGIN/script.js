const container = document.getElementById('container');
const signInEmail =  document.getElementById('signInEmail');
const signUpEmail =  document.getElementById('signUpEmail');
var attempt = 3;

  function openSignIn(){
    container.classList.remove("right-panel-active");
    if(signUpEmail.value !== ""){
      signInEmail.value = signUpEmail.value;
    }
  }

  function openSignUp(){
    container.classList.add("right-panel-active");
    if(signInEmail.value !== ""){
      signUpEmail.value = signInEmail.value;
    }
  }


  function validate(){

    var element = document.getElementById('test');
    var element = document.getElementById('ps');
    var element = document.getElementById('gender');
    var element = document.getElementById('fn');
    var element = document.getElementById('cs');
    var element = document.getElementById('m');
    var element = document.getElementById('d');
    var element = document.getElementById('y');


if (element != null && element.value == '') {

    alert("PLEASE INPUT ALL FIELDS");
}
else{
    alert("LOGIN INFO HAS BEEN SUCCESFULLY SAVE");
}
  }
  
  function resetAll() {
      attempt = 3;
      document.getElementById("signInEmail").disabled = false;
      document.getElementById("password").disabled = false;
      document.getElementById("login").disabled = false;
      document.getElementById("reset").style.display = "none";
  }
  
  
  function userLogin() {
   
    
      var username = document.getElementById("signInEmail").value;
      var password = document.getElementById("password").value;
  
      if (username == "" || password == "") {
          alert("Please complete the required field!");
      } else {
          if (username == "admin" && password == "admin"){;
              
              window.location.href = "admin.html";
          } 
        else if  (username == "user" && password == "user") {;
          window.location.href = "user.html";
        }
        else {
              attempt--;
              alert("Invalid username or password \r\nYou have left " + attempt + " attempt;");
  
              if (attempt == 0) {
                  document.getElementById("signInEmail").disabled = true;
                  document.getElementById("password").disabled = true;
                  document.getElementById("login").disabled = true;
                  document.getElementById("reset").style.display = "inline";
              }
          }
      }
  }